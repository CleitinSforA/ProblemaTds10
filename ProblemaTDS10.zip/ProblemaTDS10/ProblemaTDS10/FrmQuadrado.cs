﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProblemaTDS10
{
    public partial class FrmQuadrado : Form
    {
        public FrmQuadrado()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            
            Double lado1,  resultadoArea, resultadoPeri;
            lado1 = Convert.ToDouble(txtLado1.Text);
             
            resultadoArea = (lado1 * lado1);
            resultadoPeri = (lado1 * 4);
            lblResuArea.Text=resultadoArea.ToString("F");
            lblResuPeri.Text=resultadoPeri.ToString("F");

        }

        private void txtLado1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        
    }
}
